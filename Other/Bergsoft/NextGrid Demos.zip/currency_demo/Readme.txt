﻿Currency Demo
--------
This demo shows formatting of columns.

NextGrid supports two modes of formatting (besides custom painting). 

When the FormatType property is set to Default, the Columns (specific) 
properties are used for formatting (like decimals for a nxNumberColumn).

When FormatType is set to Format, String.Format formatting patterns/masks
can be specified with or without the index (if specified it has to be zero).

So a mask of '0:+0.00;0.00-;zero' used in a nxNumberColumn will result in formatting
of numbers as:

	positive:	+2.34
	negative:	1.25-
	zero:		zero

A mask of '0,15' will right align text (to the 15's character).

Finalyy a mask of '0:yyyy' will display only the 4 digit year of a nxGridCell in a nxDateColumn.

Masks may be specified without or without the index (0: or 0,) as '+0.00;0.00-;zero', 
',15' or 'yyyy'. Specifying an index other than 0 will result in an error.

This feature is most usefull for nxNumberColumn and nxDateColumn.

The second way of formatting the content of a nxGridCell is to implement an
OnGetCellValue handler that allows the programmer to specify what is displayed
This is most usefull for instance when a class is stored as nxGriCell and only
a property of that class is to be displayed.

A third way of formatting a cell is implement an OnGetCellColor handler for 
a nxReportGridView. This allows the programmer to specify the colors used for a 
nxGridCell.

This demo finally  shows the usage of the Fill() methods to add and a nxGridRow and 
fill it's nxGridCells with a single call.