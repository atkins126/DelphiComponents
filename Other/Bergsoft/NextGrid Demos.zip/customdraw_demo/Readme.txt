﻿NextSuite CustomDraw Demo
--------------------
This demo shows how to take total control of what is displayed inside a nxGridCell.

This is implemented by writing a CustomDrawCell event handler and do the actual 
painting there. NextGrid will call this method and indictate the state of the 
nxGridCell so the painting can be adjusted accordingly (to showing focus for instance).

The nxGridCell value is used for obtaining the Text to display inside the buttons being 
drawn in each cell.

The demo also shows that each row in a NextGrid can have it's own RowHeight, independend
of the default value set by the nxReportView. If no painting is performed for a CustomDraw
column, it will display the default painting of a nxGridCell.

Finally the demo shows you can mix CustomDraw with default painted cells on a Column by 
Column basis