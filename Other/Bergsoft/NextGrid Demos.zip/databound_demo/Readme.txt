﻿NextSuite Databound Demo
--------------------
This demo shows the power of NextGrid combined with .NET Databinding.

The demo loads the northwind database from an xml file into a datasource and 
binds it to the NextGrid. The result is that columns are automatically created 
and data is displayed. The NextGrid SelectedRow property follows the cursor 
in the database (if changed there) or updates the cursor if changed in the NextGrid.

The filter/sort buttons can be used once the database is loaded and just 
toggle a filter/sort order (and NextGrid nicely follows).

Finally does it show NextGrid ability to Hot Track (with a little bit of code).
See nextGrid1_CellStateChanged() and nxReportGridView1_GetCellColor(). 
Basically the code forces NextGrid to repaint the Hot Track Row with the 
Systems HotTrack color.