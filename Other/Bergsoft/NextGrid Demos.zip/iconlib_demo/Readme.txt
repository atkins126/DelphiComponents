﻿NextSuite IconLib Demo
--------------------
This demo shows the Nextgrid displaying the Z.IconLibrary (http://ziconlibrary.codeplex.com/).

It shows the use of a nxBindableColumn (bound to Z.IconLibrary's enum of icons) and how to supply
Images or Icons on demand for displaying in a nxIconColumn cell using it's viertual mode. 

The third column is a nxVirtualColumn that is used to display the value of the Icons Enum 
DescriptionAtribute.

The demo also contains a nxPromptLabel that automatically follows the Button when resized. 

Note: The use of nxGridCells Location property is not always allowed.
Note: The A cell in a BindableColumn does not return a value.