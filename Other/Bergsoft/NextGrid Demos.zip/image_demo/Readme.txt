﻿Image Demo
----------
This demo shows the combination of Images in an nxIconColumn with 
Color distribution Histograms based on the nxHistogram column.

The demo also shows the footer area where either predefined calulations
like Sum, Min, Max can be displayed but also Expression that are evaluated
by the nxExpression Parser. In this example the value shown is the RowCount
of the NextGrid obtained from the nxBrideBrigde RowCountproperty. 

Footer values can have text before and/or after the actual value just like 
any cell in the NextGrid.

Finaly this demo shows that Cells can contain multi-line text.