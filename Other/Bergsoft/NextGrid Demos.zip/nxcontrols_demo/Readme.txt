﻿nxCustomControls Demo
---------------------
This Demo Project is a Showcase of a number of additional control.

The following NextSuite controls are demonstrated in this Showcase.

a) nxPromptLabel. 
	This control solves the problem of tediously having 
	to align labels with controls during designing a form.
	The nxPromptLabel is simply associated with a regular Control
	like a EditoBox. If associated it will follow the control 
	when moved or resized and properly align itself with the 
	assiociated control.

b) nxFocusIndicator.
	This control shows which control has focus by drawing a colored 
	rectangle around the focussed control. Once dropped on a form it
	will start following focus amonst all controls sharing the same
	Controls container of nxFocusIndicator's parent control.

c) nxTabControl.
	This control solves a numbe of limitations of the standard 
	.Net TabControl. It can hide individual (or even all tabs).
	If all tabs are hidden the nxTabControl can be used for
	creating wizards.


d) nxDatePicker.
	This control is part of a set of Picker Controls that expose a dropdown
	part that can be used as a separate control too.

e) nxFontpicker.
	This picker control mimics the .Net Font selection dialog in it's 
	dropdown part.

f) nxTimePicker.
	This picker control uses the nxTabControl to show two different methods of 
	entering time (either numerically or by using sliders).

g) nxListBoxPicker.
	This picker control simply shows a dropdown part based on a .Net ListBox. 
	
h) nxGuidPicker.
	This picker control lets an end-user generate a Guid.
	
i) nxFilePicker
	This picker control shows a tree of files as dropdown part. It can be 
	used as a replacement for file dialog.		 

j) nxEditBox
	This box control is the base of 4 (Edit)Box alike controls that feature 
	build-in input validation (and correction if possible) plus 
	input constraints (allowed characters and if applicable min/max range 
	and precision).
	The Box controls also have built-in labels for both a prompt and units.

k) nxIntBox 
	This box control features integer input and validation. 
	When empty a hint is shows about what input is expected.

l) nxFloatBox 
	This box control features floating input and validation.
	It also allows to define a maximum precision and supports
	an easy scaling mechanism where for instance the user
	enters a value in °F but the application retrieves a °C 
	value.	
	When empty a hint is shows about what input is expected.

m) nxTimeBox
	This box control allows data entry of a time.
	When empty a hint is shows about what input is expected.

n) nxWaitCursor.
	This is not a control but a class that can be used to perform the 
	following set of tasks and have the .net Compiler enforce correct 
	execution: 

	1) Show a WaitCursor,
	2) Disable one or more Controls.
	...
	3) Re-enable previously enabled Controls
	4) REstore the previous cursor.
	Between the steps 2 and 3 code can be executed.

	The nxWaitCursor uses the IDisposable pattern and can be used 
	recursivly.
	
	Note that using Application.DoEvents between steps 2 and 3 
	will lead (by .Net design) to a change of the cursor to the 
	appropriate type. To change this you have use the nxWaitCursor 
	constructor with an explicit nxCursorMode.UseWaitCursor 
	parameter.
	
o) More to come.
