﻿NextSuite Speadsheet Demo
-------------------------
This demo shows how the nxFormulaParse that powers the nxFormulaColumn can be used
to mimic Speadsheet alike behavior.

The nxFormulaParser is a math parser that can be extended with new functions 
or constants by adding classes with static methods, properties and/or fields.

The parser natively supports simple numerical and boolean expresions (in which
case 0.0 and 1.0 are used as values for false and true).

The (return) type of methods, properties or fields must always be a Double. 
The type of methods parameters can be either String or Double.

By default the complete .Net Math class is preloaded and accessible in 
expressions (without the Math prefix) like Sqrt(25). Besides the math class
some additional math and logical methods are preloaded too.

To enable spreadsheet alike behavior the nxFormulaColumn not only preloads the Math 
and the additional math classes but also a nxGridbridge class that is the bridge 
between the nxFormulaParser and the Nexgrid. This class implements methods like 
Cell, expands speadsheet alike cell references like 'R1C1' and implements some 
commonly used functions like Avg, Std and Sum.

Please note that recaculation of a cell is performed during repaint. This may change 
in the near future to a more predictable evaluation order.

