﻿NextSuite SqlCE Demo
--------------------
This demo shows the power of NextGrid combined with SqlCE (SQL COmpact Edition).
It also shows some code to work with SqlCE (see both the SqlCE class).

The demo needs SqlCE 4.0 to be installed. It can be downloaded from:
http://www.microsoft.com/en-us/download/details.aspx?id=17876

The demo loads historical stock data into the SqlCE Database and shows it in 
NextGrid by simply using its GetCellValue method to retrieve data from the 
DataTable's DefaultView. This has the effect that the NextGrid follows and
displays whatever is in the DefaultView. 

Please note that the first time the Load Data button is pressed, the sp500hst.txt
file is converted into a SqlCE database so it will take longer then once the database 
is created.

The filtering buttons can be used once the database is loaded and just 
toggle a filter/sort order (and NextGrid nicely follows).

The only thing to keep in mind is that if the number of records changes 
in the DefaultView the NextGrid's rows must be removed BEFORE the 
operation and recreated AFTER the operation. 
See the SqlCE.DoApplySortAndFilter().

The SqlCE class also contains methods to Verify, Repair, Compact and Shrink
SqlCE databases.

The PropertyGrid is updated whenever the selection changes.

With some extra code it's possible to edit/modify the database too.

Finally does it show NextGrid ability to Hot Track (with a little bit of code).
See nextGrid1_CellStateChanged() and nxReportGridView1_GetCellColor(). 
Basically the code forces NextGrid to repaint the Hot Track Row with the 
Systems HotTrack color.