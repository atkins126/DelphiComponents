﻿NextSuite Stock Demo
--------------------
This demo shows the power of views combined with the nxSparkLineColumn and 
nxHistogramColumn.

The demo loads historical stock data into the nextGrid and shows it in various 
views without alteration of rows, columns or columns.

The StockDemo shows the standard report view, the slides view (where each row 
is represented by a slide where cells and labels can be arranged freely) and 
a listview that is still in beta and that is not fully functionally yet.

Nextgrid can show one view at a time. When a slides view is displayed it displays 
a single slides design within the slides view. Views are switched by changing 
Nextgrid's ActiveView index.

Views are defined by the Views Editor that is build into the Nextgrid and 
that can be access by the Visual Studio properties window, designer verbs 
that can be accessed through either the bottom part of the properties window 
or the verbs menu located in the top left corner of the Nextgrid in designer 
view.

The slides view can contain multiple slides designers that can easily be 
switched by changing the ActiveSlide property of the Slide View. Slides are 
designer with the Slides Editor that is available at the same locations as
the Views Editor.

Both nxHistogramColumn and nxSparkLine column will only render a graph when
an array of Double value is supplied. The nxHistogramColumn has a static 
method to sort/count an array of Double value into an array of bins 
containing occurences of values in a certain range.

Finally this demo also shows the usage of nxWaitCursor, a small IDisposable 
derived class that is used to temporarily show a waitcursor and disable both
buttons.