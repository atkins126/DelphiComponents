﻿Xml Demo
--------
This demo shows the a visualisation of a Xml Document using the nxTreeColumn in 
combination with additional nxTextColumn. It also shows the usage of the 
nxGridCell's value being an Object instead of somethign like a String.

The xml is recursively read and simply loaded into the nxTreeColumn as 
nxGridCell values.

The NextGrid's CustomCellContent event is used to return the actual displayed 
value, in this demo the XmlElement's Name property when CustomCellContent is
invoked for the nxTreeColumn.

This demo also shows the convienance of methods like AddChildRow returning 
the newly added nxGridRow and usage of the Fill method that allows the
program to create and fill a row in a single statement with syntax like:

	nextGrid1.AddChildRow(y.AbsoluteIndex).Fill(att, att.Value);

As Fill itself also returns the nxGridRow it fills with data, statements 
like this can be extended even further with assiging a property like

	nextGrid1.AddChildRow(y.AbsoluteIndex).Fill(att, att.Value).ImageIndex = GetImageIndex(att);

which can eliminate the need for a temporary object like in:

	nxGridRow y = nextGrid1.AddChildRow(parentrow.AbsoluteIndex).Fill(elem, String.Empty);
	y.ImageIndex = GetImageIndex(elem);


